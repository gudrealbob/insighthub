# InsightHub Parser Fix 2.1 — Complete Replacement Package

This package implements the agreed business rules for the unresolved parser messages.

## Business rules implemented

1. `#Freshview` is authoritative and always represents a new `BUY` recommendation.
2. `#Update` is authoritative for exits, selling, booked profit, target/SL updates, and lifecycle changes.
3. Humor and conversational wording are supported for tickers such as HOT, BAT, BAKE, NANO, COW, and PHB.
4. Entry instructions are stored separately:
   - `CURRENT_PRICE`
   - `BUY_ON_DIPS`
   - `ADD`
   - `AVERAGE`
   - `REENTRY`
   - `STAGED_ENTRY`
5. A missing message price is valid. It is stored with `entry_price_source = MARKET_LOOKUP_PENDING`.
6. `stop_loss`, `support_level`, and `trigger_level` are separate fields.
7. `Tgt open` is stored numerically as `999`, with `targets_json.target_type = OPEN`.
8. `instrument_type` always falls back to `UNKNOWN`, preventing the earlier NOT NULL error.
9. Raw `messages` rows remain immutable.

## Files

| File | Action |
|---|---|
| `app/parsers/__init__.py` | Replace |
| `app/parsers/recommendation_parser.py` | Replace |
| `app/models/recommendation.py` | Replace |
| `app/services/recommendation_service.py` | Replace |
| `app/services/message_reprocessing_service.py` | Replace |
| `tests/test_recommendation_parser_v2_1.py` | New |

## Important compatibility check

The supplied `Recommendation` model preserves the fields used by the current parser-correction package. Before replacing it, compare it with your local file for any later Sprint 4/5 performance fields. If your local model contains additional fields, retain those additional fields below the fields supplied here.

## Database migration

This change adds recommendation columns. Use Alembic autogenerate, as required for InsightHub.

```bash
alembic revision --autogenerate -m "add parser entry and level fields"
```

Review the generated migration. It should add:

- `entry_instruction`
- `entry_instruction_text`
- `entry_price_source`
- `entry_price_timestamp`
- `support_level`
- `trigger_level`

Then apply it:

```bash
alembic upgrade head
```

Do not manually create the Alembic version file.

## Safe execution order

### 1. Back up derived tables

```bash
docker exec -i homelab-postgres pg_dump \
  -U homelab_admin \
  -d ihub \
  --table=normalized_messages \
  --table=recommendations \
  > before_parser_v2_1.sql
```

### 2. Copy the files

Copy the package contents into the InsightHub project root while preserving paths.

### 3. Generate and apply migration

```bash
alembic revision --autogenerate -m "add parser entry and level fields"
alembic upgrade head
```

### 4. Run parser tests

```bash
pytest tests/test_recommendation_parser_v2_1.py -v
```

### 5. Dry-run reprocessing

```bash
python -m scripts.reprocess_messages --dry-run
```

### 6. Commit reprocessing

```bash
python -m scripts.reprocess_messages
```

### 7. Regenerate unresolved report

```bash
python -m scripts.parser_quality_report
```

## Validation SQL

```sql
SELECT parser_status, COUNT(*)
FROM normalized_messages
GROUP BY parser_status
ORDER BY parser_status;
```

```sql
SELECT COUNT(*)
FROM normalized_messages
WHERE instrument_type IS NULL;
```

Expected: `0`.

```sql
SELECT
    r.message_id,
    r.symbol,
    r.action,
    r.entry_low,
    r.entry_high,
    r.entry_instruction,
    r.entry_price_source,
    r.support_level,
    r.trigger_level,
    r.target1,
    r.targets_json
FROM recommendations r
JOIN messages m ON m.id = r.message_id
WHERE m.id IN (
    1741, 1742, 1748, 1754, 1792, 1813, 1818, 1823,
    1824, 1829, 1831, 1833, 1845, 1848, 1850, 1862,
    1871, 1875, 1955, 1977, 1984, 2012, 2040, 2046
)
ORDER BY r.message_id;
```

## Current-price enrichment boundary

The parser does not call a market API. For recommendations with no stated entry:

```text
entry_low = NULL
entry_high = NULL
entry_price_source = MARKET_LOOKUP_PENDING
```

A later price-enrichment service should retrieve the historical market price nearest to `messages.message_date`, populate both entry values, set `entry_price_source = MARKET_LOOKUP`, and populate `entry_price_timestamp`.
